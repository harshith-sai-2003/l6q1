/*
Create a home page of “XYZ Institute” where in the menu based on Option Menu is used with the following Requirements
a)Create a simple option menus where in once you click the “menu options”, the option items should get displayed which are “Courses”,”Admission”,”Faculty”.
  On click of each item corresponding content should get displayed .Eg. Courses should display all the course details offered by the institute.
  Admission should display all the details regarding admission procedure.Faculty should display the details photo of each faculty.
b)This option menu uses images/icons instead of textual content. This textual content should represent “Contact US”, “About Us”,” Homepage”.
  Once the user clicks on the corresponding icons it should display corresponding content.
*/

package com.example.l6q1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuInflater;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}